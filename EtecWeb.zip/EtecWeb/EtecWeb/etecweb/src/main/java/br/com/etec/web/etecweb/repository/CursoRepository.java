package br.com.etec.web.etecweb.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import br.com.etec.web.etecweb.entity.Curso;

public interface CursoRepository extends JpaRepository<Curso, Integer>{

}
