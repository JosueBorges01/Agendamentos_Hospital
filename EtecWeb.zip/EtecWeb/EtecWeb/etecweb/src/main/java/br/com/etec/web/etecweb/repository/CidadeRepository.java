package br.com.etec.web.etecweb.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.etec.web.etecweb.entity.Cidade;

public interface CidadeRepository extends JpaRepository<Cidade, Integer>{


}