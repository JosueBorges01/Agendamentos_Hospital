package br.com.etec.web.etecweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtecwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EtecwebApplication.class, args);
	}

}
