package br.com.etec.web.etecweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;


import br.com.etec.web.etecweb.entity.Curso;
import br.com.etec.web.etecweb.service.CursoService;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
@RequestMapping("/cursos")
public class CursoController {

  // Injeção de Independência//
  @Autowired
  private CursoService cursoService;

  // metodo para salvar um aluno//
  @PostMapping("/salvar")
  public String salvar(@ModelAttribute Curso curso) {
    // Salvar Aluno
    cursoService.save(curso);
    // redireciona para lista alunos//
    return "redirect:/cursos/listar";
  }

  @GetMapping("/listar")
  public String listar(Model model) {
    // Listar todos os alunos
    List<Curso> cursos = cursoService.findAll();
    model.addAttribute("cursos", cursos);
    // retorna a pagia de lista de alunos
    return "cursos/listaCurso";
  }

  // metodo para abrir o formulário de criação de alunos
  @GetMapping("/criar")
  public String criarForm(Model model) {
    // Adiciona um novo aluno ao modelo
    model.addAttribute("curso", new Curso());
    // Retorna a página do formulário de alunos
    return "cursos/formularioCurso";

  }
  
  @GetMapping("/editar/{id}")
  public String editar(@PathVariable Integer id, Model model) {
      Curso curso = cursoService.findById(id);
      model.addAttribute("curso", curso);
      return "cursos/formularioCurso";
  }

  //Método para excluir um aluno
  @GetMapping("/excluir/{id}")
  //excluir um aluno pelo id
  public String excluir(@PathVariable Integer id) {
    cursoService.deleteById(id);
      return "redirect:/cursos/listar";
  }


}
