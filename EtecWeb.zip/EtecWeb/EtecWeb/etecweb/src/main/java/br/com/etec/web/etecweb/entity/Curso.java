package br.com.etec.web.etecweb.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Curso {
    
@Id
@GeneratedValue (strategy = GenerationType.AUTO)
private Integer idCurso;

@Column (nullable = false, length = 40)
private String nomeCurso;

@Column (nullable = false, length = 40)
private String periodoCurso;

@Column (nullable = false, length = 40)
private Integer cargaHoraria;


public Curso() {

}

/* metodos construtor cheio */
public Curso(int idCurso, String nomeCurso, String periodoCurso, Integer cargaHoraira) {
    this.idCurso= idCurso;
    this.nomeCurso = nomeCurso;
    this.periodoCurso = periodoCurso;
    this.cargaHoraria = cargaHoraira;
}
/* metodos acessores - Set's e Get's */

public Integer getIdCurso() {
    return idCurso;
}

public void setIdCurso(Integer idCurso) {
    this.idCurso = idCurso;
}

public String getNomeCurso() {
    return nomeCurso;
}

public void setNomeCurso(String nomeCurso) {
    this.nomeCurso = nomeCurso;
}

public String getPeriodoCurso() {
    return periodoCurso;
}

public void setPeriodoCurso(String periodoCurso) {
    this.periodoCurso = periodoCurso;
}

public Integer getCargaHoraria() {
    return cargaHoraria;
}

public void setCargaHoraria(Integer cargaHoraria) {
    this.cargaHoraria = cargaHoraria;
}

// id//


/*
 * O método set (atribuir) é utilizado para receber os dados dos atributos e
 * injetá-los. E o método get (pegar), por sua vez, é utilizado para obter e
 * retornar o valor “setado”
 */

}






//nome periodo cargaHoraira//