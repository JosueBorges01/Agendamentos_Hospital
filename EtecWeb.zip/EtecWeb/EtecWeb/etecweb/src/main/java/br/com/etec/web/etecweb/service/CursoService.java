package br.com.etec.web.etecweb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.etec.web.etecweb.entity.Curso;
import br.com.etec.web.etecweb.repository.CursoRepository;

@Service
public class CursoService {
 
    //Injeção de independência//
    @Autowired
    private CursoRepository cursoRepository;

    //Metodo para salvar um aluno//
    public Curso save(Curso curso){
        return cursoRepository.save(curso);
    }
    
    //Metodo para listar todos os alunos//
    public List<Curso> findAll(){
        return cursoRepository.findAll();
    } 

    
    //método para excluir um aluno pelo id
    public void deleteById(Integer id){
        cursoRepository.deleteById(id);
    }

    public Curso findById(Integer id){
        return cursoRepository.findById(id).orElse(null);
    }


    }
