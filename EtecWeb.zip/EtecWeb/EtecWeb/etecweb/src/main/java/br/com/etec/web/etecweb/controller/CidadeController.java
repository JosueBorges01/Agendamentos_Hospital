package br.com.etec.web.etecweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import br.com.etec.web.etecweb.entity.Cidade;
import br.com.etec.web.etecweb.service.CidadeService;


import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
@RequestMapping("/cidades")
public class CidadeController {

  // Injeção de Independência//
  @Autowired
  private CidadeService cidadeService;

  // metodo para salvar um aluno//
  @PostMapping("/salvar")
  public String salvar(@ModelAttribute Cidade cidade) {
    // Salvar Aluno
    cidadeService.save(cidade);
    // redireciona para lista alunos//
    return "redirect:/cidades/listar";
  }

  @GetMapping("/listar")
  public String listar(Model model) {
    // Listar todos os alunos
    List<Cidade> cidades = cidadeService.findAll();
    model.addAttribute("cidades", cidades);
    // retorna a pagia de lista de alunos
    return "cidades/listaCidade";
  }

  // metodo para abrir o formulário de criação de alunos
  @GetMapping("/criar")
  public String criarForm(Model model) {
    // Adiciona um novo aluno ao modelo
    model.addAttribute("cidade", new Cidade());
    // Retorna a página do formulário de alunos
    return "cidades/formularioCidade";

  }
  
  @GetMapping("/editar/{id}")
  public String editar(@PathVariable Integer id, Model model) {
      Cidade cidade = cidadeService.findById(id);
      model.addAttribute("cidade", cidade);
      return "cidades/formularioCidade";
  }

  //Método para excluir um aluno
  @GetMapping("/excluir/{id}")
  //excluir um aluno pelo id
  public String excluir(@PathVariable Integer id) {
    cidadeService.deleteById(id);
      return "redirect:/cidades/listar";
  }


}
