package br.com.etec.web.etecweb.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import br.com.etec.web.etecweb.entity.Aluno;

public interface AlunoRepository extends JpaRepository<Aluno, Integer>{

}
