package br.com.etec.web.etecweb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.etec.web.etecweb.entity.Cidade;
import br.com.etec.web.etecweb.repository.CidadeRepository;


@Service
public class CidadeService {
 
    //Injeção de independência//
    @Autowired
    private CidadeRepository cidadeRepository;

    //Metodo para salvar um aluno//
    public Cidade save(Cidade cidade){
        return cidadeRepository.save(cidade);
    }
    
    //Metodo para listar todos os alunos//
    public List<Cidade> findAll(){
        return cidadeRepository.findAll();
    } 

    
    //método para excluir um aluno pelo id
    public void deleteById(Integer id){
        cidadeRepository.deleteById(id);
    }

    public Cidade findById(Integer id){
        return cidadeRepository.findById(id).orElse(null);
    }


    }
