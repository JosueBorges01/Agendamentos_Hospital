package br.com.etec.web.etecweb.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import br.com.etec.web.etecweb.entity.Aluno;
import br.com.etec.web.etecweb.entity.Cidade;
import br.com.etec.web.etecweb.entity.Curso;
import br.com.etec.web.etecweb.service.AlunoService;
import br.com.etec.web.etecweb.service.CidadeService;
import br.com.etec.web.etecweb.service.CursoService;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;



@Controller
@RequestMapping("/alunos")
public class AlunoController {

  // Injeção de Independência//
  @Autowired
  private AlunoService alunoservice;

  @Autowired
  private CursoService cursoService;

  @Autowired
  private CidadeService cidadeService;

  // metodo para salvar um aluno//
  @PostMapping("/salvar")
  public String salvar(@ModelAttribute Aluno aluno) {
    // Salvar Aluno
    alunoservice.save(aluno);
    // redireciona para lista alunos//
    return "redirect:/alunos/listar";
  }

  @GetMapping("/listar")
  public String listar(Model model) {
    // Listar todos os alunos
    List<Aluno> alunos = alunoservice.findAll();
    model.addAttribute("alunos", alunos);
    // retorna a pagia de lista de alunos
    return "alunos/listaAluno";
  }

  // metodo para abrir o formulário de criação de alunos
  @GetMapping("/criar")
  public String criarForm(Model model) {
    // Adiciona um novo aluno ao modelo
    model.addAttribute("aluno", new Aluno());
    List<Curso> cursos = cursoService.findAll();
    model.addAttribute("cursos", cursos);
    List<Cidade> cidades = cidadeService.findAll();
    model.addAttribute("cidades", cidades);
    // Retorna a página do formulário de alunos
    return "alunos/formularioAluno";

  }

  //Método para excluir um aluno
  @GetMapping("/excluir/{id}")
  //excluir um aluno pelo id
  public String excluir(@PathVariable Integer id) {
    alunoservice.deleteById(id);
      return "redirect:/alunos/listar";
  }

  @GetMapping("/editar/{id}")
  public String editar(@PathVariable Integer id, Model model) {
      Aluno aluno = alunoservice.findById(id);
      model.addAttribute("aluno", aluno);
      List<Curso> cursos = cursoService.findAll();
      model.addAttribute("cursos", cursos);
      List<Cidade> cidades = cidadeService.findAll();
    model.addAttribute("cidades", cidades);
      
      return "alunos/formularioAluno";
  
  }
}
