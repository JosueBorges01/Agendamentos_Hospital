package br.com.etec.web.etecweb.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


/* Ele cria ja os metedos set e ger e os construtore. ele servem pra otimizar*/
@Entity
@Getter   
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Aluno {

    @Id /* chvae primaria */
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer idAluno;

    @Column(nullable = false, length = 40)
    private String nomeAluno;

    @Column(nullable = true, length = 11)
    private String cpfAluno;

    @Column(nullable = false, length = 30)
    private String enderecoAluno;

    @Column(nullable = true, length = 11)
    private String telefoneAluno;

    private Integer rmAluno;



/*Muitor pra um, Além disso ele ja cria a chave estrangeira e a tabela */
@ManyToOne
@JoinColumn(name = "idCurso-fk")
private Curso curso;

@ManyToOne
@JoinColumn(name = "idCidade-fk")
private Cidade cidade;

}
    // id//
    
    /*
     * O método set (atribuir) é utilizado para receber os dados dos atributos e
     * injetá-los. E o método get (pegar), por sua vez, é utilizado para obter e
     * retornar o valor “setado”
     */

/*Relacionamento


Primeira regra de integridade de um banco de dados:
Chave Primaria;

Segunda regra de integridade de um banco de dado:
relacionamento : muitos pra um 
serve para não ter dados falsos;



Abrir a Entity Alunos

;;


Criar uma Cidadade

como nome e id */
    
