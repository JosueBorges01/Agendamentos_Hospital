package br.com.etec.web.etecweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtecwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
